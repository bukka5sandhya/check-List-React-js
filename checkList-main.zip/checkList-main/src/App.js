import './App.css';
import CheckList from './components/CheckList';

function App() {
  return (
    <div className="App">
      <CheckList/>
    </div>
  );
}

export default App;
